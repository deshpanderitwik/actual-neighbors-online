#!/usr/bin/env python3
"""
Where everything lives.

Every path used to be written into the source, pointing at one machine. This
reads `config.json` in the data directory instead, filling in whatever it can
work out on its own. The app's first-run setup writes that file (`Setup` in
`menubar/main.swift`); `python3 config.py` prints what resolved and what's
missing.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

HOME = Path.home()

# Where the code is, and where its working files go. These are the same folder
# in a checkout, and different ones once the app is signed: a signed bundle
# must not be written into, or its signature breaks and Gatekeeper rejects it.
CODE_DIR = Path(__file__).resolve().parent
DATA_DIR = (
    CODE_DIR
    if CODE_DIR.name != "Resources"
    else HOME / "Library" / "Application Support" / "Instrument Explorer"
)
DATA_DIR.mkdir(parents=True, exist_ok=True)

CONFIG_FILE = DATA_DIR / "config.json"
INDEX_FILE = DATA_DIR / "index.json"
HERE = CODE_DIR  # kept for callers that just want the code's folder

# Live's own folders are in the same place on every Mac.
USER_LIBRARY = HOME / "Music" / "Ableton" / "User Library"
REMOTE_SCRIPTS = USER_LIBRARY / "Remote Scripts"

# The preset skeleton is lifted from a .adg Live wrote, so one ships with the
# app rather than being looked up in a library the machine may not have.
TEMPLATE = CODE_DIR / "assets" / "preset-template.adg"

# One source for the version: the VERSION file, which build.sh also stamps into
# the bundle's Info.plist. The shell compares its own version against whatever
# `/api/status` reports, so that a new app never adopts an old server and keeps
# running its code — which is what made upgrades silently do nothing.
def _version() -> str:
    f = CODE_DIR / "VERSION"
    try:
        return f.read_text().strip() or "dev"
    except OSError:
        return "dev"


VERSION = _version()


class ConfigError(RuntimeError):
    pass


def _first_existing(*candidates: Path) -> Path | None:
    return next((c for c in candidates if c.is_dir()), None)


def guess_projects_root() -> Path | None:
    """A folder full of Ableton project folders."""
    return _first_existing(
        HOME / "Dropbox" / "AN" / "01 Tracks",
        HOME / "Library" / "CloudStorage" / "Dropbox" / "AN" / "01 Tracks",
        HOME / "Music" / "Ableton" / "Projects",
        HOME / "Music" / "Projects",
    )


def load() -> dict:
    """Resolved settings. Missing optional paths come back as None."""
    raw: dict = {}
    if CONFIG_FILE.exists():
        try:
            raw = json.loads(CONFIG_FILE.read_text())
        except json.JSONDecodeError as e:
            raise ConfigError(f"{CONFIG_FILE.name} is not valid JSON: {e}")

    def path_of(key: str, default: Path | None = None) -> Path | None:
        v = raw.get(key)
        return Path(v).expanduser() if v else default

    projects = path_of("projects_root", guess_projects_root())
    if not projects or not projects.is_dir():
        raise ConfigError(
            "projects_root is not set or does not exist. Open Instrument "
            "Explorer, which asks for it on first run, or put it in "
            f"{CONFIG_FILE}."
        )

    user_library = path_of("user_library", USER_LIBRARY)
    # Staging lives in the User Library by default because Live always shows
    # that folder in its browser — no Place for the user to set up by hand.
    staging = path_of("staging", user_library / "_instrument-explorer")

    library = path_of("library_root")
    if library and not library.is_dir():
        library = None

    # Anything previews or samples may be read from.
    roots = [projects, user_library]
    if library:
        roots.append(library)
    for extra in raw.get("extra_roots", []):
        p = Path(extra).expanduser()
        if p.is_dir():
            roots.append(p)
    # A sample often sits outside the project, in a packs folder alongside it.
    if projects.parent.is_dir():
        roots.append(projects.parent)

    return {
        "projects_root": projects,
        "library_root": library,
        "user_library": user_library,
        "staging": staging,
        "template": TEMPLATE,
        "min_project": int(raw.get("min_project", 0)),
        "audio_roots": sorted({str(r) for r in roots}),
    }


def main() -> None:
    try:
        cfg = load()
    except ConfigError as e:
        print(f"not configured: {e}", file=sys.stderr)
        raise SystemExit(1)
    print(f"  {'code':<14} : {CODE_DIR}")
    print(f"  {'data':<14} : {DATA_DIR}")
    width = max(len(k) for k in cfg)
    for k, v in cfg.items():
        if isinstance(v, list):
            print(f"  {k:<{width}} :")
            for item in v:
                print(f"  {'':<{width}}   {item}")
        else:
            mark = "" if v is None or Path(str(v)).exists() else "   (missing)"
            print(f"  {k:<{width}} : {v}{mark}")


if __name__ == "__main__":
    main()
