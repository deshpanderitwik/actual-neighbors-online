#!/usr/bin/env python3
"""
Turn a track inside a saved Live set into a .adg Instrument Rack preset, which
is the only thing Live's API will actually load.

Why this exists: `browser.load_item` materialises device presets and nothing
else. A .als reports itself loadable and the call returns cleanly, but nothing
arrives — same for .alc. Verified with a track selected and with a clip slot
highlighted. So to get a layer into the open set, its device chain has to be
rewritten as a preset.

That turns out to be mostly lifting rather than synthesis:

  * a native Ableton device is stored inside a preset in exactly the same form
    it takes inside a set, so it just needs an <AbletonDevicePreset> wrapper;
  * a plug-in already carries a complete, ready-made <AuPreset> (or Vst3Preset)
    nested in <PluginDesc><...PluginInfo><Preset>, binary state buffer and all,
    so it is copied out verbatim.

Everything around the device list — the Instrument Rack that holds the chain,
the branch's mixer, the return branches — is lifted from a known-good .adg that
Live itself wrote, rather than invented here.
"""
from __future__ import annotations

import gzip
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import config  # noqa: E402
from extract_track import ExtractError, STAGING, repoint_samples, safe_name  # noqa: E402

# A preset Live wrote, shipped with the app and used as the skeleton for
# the ones we write.
TEMPLATE = config.TEMPLATE

TRACK_RE = re.compile(r'<(AudioTrack|MidiTrack|GroupTrack) Id="(\d+)"')
PLUGIN_TAGS = ("AuPluginDevice", "PluginDevice", "Vst3PluginDevice")

# Racks are NOT convertible by embedding their set XML, and getting this wrong
# is not a soft failure — it crashed Live outright.
#
# Inside a set a rack carries its chains in a populated <Branches>. Inside a
# preset it must carry <Branches /> empty, with every chain restated in a
# sibling <BranchPresets> as a *BranchPreset (and a nested rack wrapped in its
# own <GroupDevicePreset>). Those are different schemas, so a rack needs a real
# recursive rewrite rather than a copy. Until that exists, refuse.
RACK_TAGS = ("DrumGroupDevice", "InstrumentGroupDevice",
             "AudioEffectGroupDevice", "MidiEffectGroupDevice")

# Devices Live refuses to load from inside a rack preset — see UnloadableInRack
# for how this was established and how to re-test it. Measured, not guessed:
# tests/sweep grafts one device at a time into a factory rack known to load.
UNLOADABLE_IN_RACK: frozenset[str] = frozenset({"Erosion2"})


class NeedsRackSupport(ExtractError):
    """Raised for a layer whose chain contains a rack, so callers can fall back
    to staging instead of writing a preset that would take Live down."""


class UnloadableInRack(ExtractError):
    """A device Live will not load from inside a rack preset at all.

    Not a conversion problem: the preset holds the device correctly and the
    offline rung agrees. Live simply refuses the whole document when one of
    these is present, with no error of any kind — it creates the track and
    loads nothing onto it.

    Established against a known-good base rather than inferred. A factory
    Instrument Rack (`E-Piano Wurli.adg`) loads its four devices; add one of
    these devices to it, from the factory's own `.adv`, and Live rejects the
    whole rack. Ableton ships none of them in any of the 2163 rack presets in
    the Core Library and Factory Packs, which is consistent.

    Observed on Live 12.4.7. `verify.py live` is how to re-test it: if a
    later Live fixes this, the sweep in `tests/` will say so and the entry
    comes out.
    """


class FidelityError(ExtractError):
    """Raised when a preset would be written with devices missing.

    The point is that a partial conversion is worse than none: a thinned rack
    looks like it worked, so it is trusted, and the missing half is discovered
    much later in a track that is already being mixed. Staging the whole track
    instead is lossless and obviously a fallback.
    """


class Ledger:
    """Everything the conversion could not carry, and why.

    The empty-rack bug survived as long as it did because every loss was
    silent. `chain_devices()` returned `[]` for a wrapper tag it did not know,
    `device_preset()` returned `None`, and both were filtered out with a bare
    `if p`. `build()` raised only when *every* device failed, so a chain that
    lost 68 of its 69 devices reported success and Live showed an empty rack
    with no error anywhere. Nothing can be made trustworthy while it can fail
    that quietly, so each drop is recorded here and `build(strict=True)`
    refuses to write the preset at all.
    """

    def __init__(self) -> None:
        self.drops: list[dict] = []

    def drop(self, path: str, kind: str, reason: str) -> None:
        self.drops.append({"path": path, "device": kind, "reason": reason})

    def __bool__(self) -> bool:
        return bool(self.drops)

    def __len__(self) -> int:
        return len(self.drops)

    def summary(self, limit: int = 6) -> str:
        head = "; ".join(f"{d['device']} at {d['path'] or '/'} ({d['reason']})"
                         for d in self.drops[:limit])
        more = len(self.drops) - limit
        return f"{len(self.drops)} device(s) could not be converted: " + head + (
            f"; and {more} more" if more > 0 else "")


# --------------------------------------------------------------------------- #
# small XML helpers — the documents are far too large for a DOM
# --------------------------------------------------------------------------- #
def element(src: str, tag: str, start: int = 0) -> tuple[int, int] | None:
    """Byte range of the first <tag …>…</tag> (or self-closing) at or after start."""
    esc = re.escape(tag)
    m = re.search(r"<%s(\s[^>]*?)?(/?)>" % esc, src[start:])
    if not m:
        return None
    s = start + m.start()
    if m.group(2) == "/":
        return s, start + m.end()
    depth, pos = 1, start + m.end()
    pat = re.compile(r"<(/?)%s(\s[^>]*?)?(/?)>" % esc)
    while depth:
        m2 = pat.search(src, pos)
        if not m2:
            return None
        if m2.group(1):
            depth -= 1
        elif not m2.group(3):
            depth += 1
        pos = m2.end()
    return s, pos


def children(src: str) -> list[tuple[str, int, int]]:
    """Direct child elements of a fragment, as (tag, start, end).

    Tag names may contain dots: Live writes a rack's macro knobs as
    <MacroControls.0>, <MacroDefaults.0> and so on. Matching only \\w+ skips
    those elements silently, and anything rebuilt from the result comes back
    missing its macros — which Live rejects without a word.
    """
    out, depth, pos = [], 0, 0
    for m in re.finditer(r"<(/?)([\w.]+)(\s[^>]*?)?(/?)>", src):
        close, tag, _attrs, selfc = m.groups()
        if close:
            depth -= 1
            if depth == 0:
                out[-1] = (out[-1][0], out[-1][1], m.end())
            continue
        if depth == 0:
            out.append((tag, m.start(), m.end() if selfc else -1))
        if not selfc:
            depth += 1
    return [c for c in out if c[2] != -1]


def inner(src: str, span: tuple[int, int], tag: str) -> str:
    """Contents of <tag> within span, excluding the tag itself."""
    frag = src[span[0]:span[1]]
    r = element(frag, tag)
    if not r:
        return ""
    body = frag[r[0]:r[1]]
    return re.sub(r"^<%s(\s[^>]*?)?>|</%s>$" % (tag, tag), "", body).strip()


# --------------------------------------------------------------------------- #
# template pieces
# --------------------------------------------------------------------------- #
class Template:
    def __init__(self, path: Path = TEMPLATE):
        if not path.exists():
            raise ExtractError(f"preset template missing: {path}")
        src = gzip.decompress(path.read_bytes()).decode("utf-8", "replace")
        self.header = src[:src.index("<GroupDevicePreset>")]

        gdp = element(src, "GroupDevicePreset")
        if not gdp:
            raise ExtractError("template has no GroupDevicePreset")
        body = src[gdp[0]:gdp[1]]

        def take(tag: str) -> str:
            r = element(body, tag)
            return body[r[0]:r[1]] if r else ""

        self.rack_device = take("Device")          # the empty Instrument Rack
        self.preset_ref = take("PresetRef")
        self.return_branches = take("ReturnBranchPresets")

        br = element(body, "InstrumentBranchPreset")
        if not br:
            raise ExtractError("template has no InstrumentBranchPreset")
        branch = body[br[0]:br[1]]
        dp = element(branch, "DevicePresets")
        # Everything after the device list: mixer, zone settings, colours.
        self.branch_tail = branch[dp[1]:branch.rindex("</InstrumentBranchPreset>")]
        self.branch_open = branch[:dp[0]]


# --------------------------------------------------------------------------- #
# device -> device preset
# --------------------------------------------------------------------------- #
_TPL: "Template | None" = None


def shared_template() -> "Template":
    global _TPL
    if _TPL is None:
        _TPL = Template()
    return _TPL


# set form -> preset form
BRANCH_PRESET_TAG = {
    "DrumBranch": "DrumBranchPreset",
    "InstrumentBranch": "InstrumentBranchPreset",
    "AudioEffectBranch": "AudioEffectBranchPreset",
    "MidiEffectBranch": "MidiEffectBranchPreset",
    # A rack's return chains are plain audio-effect branches once in a preset
    # (confirmed against Enigma Kit.adg).
    "ReturnBranch": "AudioEffectBranchPreset",
}
EMPTY_ZONE = ('<ZoneSettings>\n<ReceivingNote Value="0" />\n'
              '<SendingNote Value="60" />\n<ChokeGroup Value="0" />\n</ZoneSettings>')

# SourceContext records where a chain was dragged in from. The two forms are
# not interchangeable: a preset holds <BranchSourceContext> directly, a set
# wraps a differently-named <SourceContext> inside <Value>, and carries a file
# reference from whatever machine wrote it. Grafting the set form into an
# otherwise-valid factory kit is enough on its own to make Live reject the
# whole preset, so it is replaced with an empty one. It is only provenance —
# what the browser shows as the chain's origin — and nothing depends on it.
CLEAN_SOURCE_CONTEXT = (
    '<SourceContext>\n<BranchSourceContext Id="0">\n'
    "<OriginalFileRef />\n"
    '<BrowserContentPath Value="" />\n'
    '<LocalFiltersJson Value="" />\n'
    "<PresetRef />\n"
    '<BranchDeviceId Value="" />\n'
    "</BranchSourceContext>\n</SourceContext>"
)


def direct(body: str) -> dict[str, str]:
    """Direct children of a fragment, keyed by tag (first wins).

    Searching the whole fragment would be wrong: tags like SourceContext and
    Name also occur deep inside the devices a branch contains.
    """
    out: dict[str, str] = {}
    for tag, s, e in children(body):
        out.setdefault(tag, body[s:e])
    return out


def strip_tag(frag: str, tag: str) -> str:
    """Contents of <tag>…</tag>, tag removed."""
    body = re.sub(r"^<%s(\s[^>]*?)?>" % re.escape(tag), "", frag)
    i = body.rfind("</%s>" % tag)
    return body[:i] if i >= 0 else body


def chain_devices(chain_xml: str) -> list[tuple[str, str]]:
    """Devices held by a branch's device chain.

    The wrapper's tag depends on the chain's signal flow: `<DeviceChain>` on a
    track, but `<MidiToAudioDeviceChain>` on an instrument branch and
    `<AudioToAudioDeviceChain>` on an audio-effect branch. This used to look
    for `Devices` and then for a child named exactly `DeviceChain`, so inside
    a rack it matched neither and returned nothing — every branch was written
    out empty and the rack arrived in Live with nothing in it. Live reports no
    error for that, which is why it went unnoticed for so long.

    So any child whose tag ends in `DeviceChain` is descended into, and the
    wrapper is stripped by its own name rather than an assumed one.
    """
    m = re.match(r"<([\w.]+)", chain_xml)
    body = strip_tag(chain_xml, m.group(1) if m else "DeviceChain")
    kids = direct(body)
    if "Devices" in kids:
        inner = strip_tag(kids["Devices"], "Devices").strip()
        return [(t, inner[s:e]) for t, s, e in children(inner)]
    for tag, frag in kids.items():
        if tag.endswith("DeviceChain"):
            return chain_devices(frag)
    return []


def devices_present(frag: str) -> int:
    """How many devices a fragment holds, counted structurally.

    A cross-check on `chain_devices()` that shares none of its assumptions:
    whatever sits in a `<Devices>` list is a device, no matter what wraps it.
    If this finds devices and `chain_devices()` found none, the walk has gone
    blind to a new wrapper tag — so the ledger says so instead of the branch
    being quietly written out empty.
    """
    total, pos = 0, 0
    while True:
        r = element(frag, "Devices", pos)
        if not r:
            return total
        total += len(children(strip_tag(frag[r[0]:r[1]], "Devices").strip()))
        pos = r[0] + 1


# Three device fields exist only in the set form; Live never writes them into a
# preset. Leaf devices tolerate them, but a rack does not.
SET_ONLY_FIELDS = ("BreakoutIsExpanded", "MpePitchBendUsesTuning", "ViewData")


def strip_set_only(device_xml: str, tag: str) -> str:
    body = strip_tag(device_xml, tag)
    open_tag = device_xml[:device_xml.index(">") + 1]
    kept = []
    for t, s, e in children(body):
        if t in SET_ONLY_FIELDS:
            continue
        # Same incompatibility as on a branch, so drop the provenance here too.
        kept.append("<SourceContext />" if t == "SourceContext" else body[s:e])
    return open_tag + "\n" + "\n".join(kept) + f"\n</{tag}>"


def mixer_preset(mixer_xml: str) -> str:
    body = strip_tag(mixer_xml, "MixerDevice")
    kept = [body[s:e] for t, s, e in children(body) if t not in SET_ONLY_FIELDS]
    dev = ('<AudioBranchMixerDevice Id="0">\n' + "\n".join(kept)
           + "\n</AudioBranchMixerDevice>")
    return (f'<MixerPreset>\n<AbletonDevicePreset Id="0">\n'
            f'<OverwriteProtectionNumber Value="3075" />\n'
            f"<Device>\n{dev}\n</Device>\n"
            f"</AbletonDevicePreset>\n</MixerPreset>")


def branch_preset(tag: str, xml: str, idx: int,
                  lost: "Ledger | None" = None, path: str = "") -> str:
    """Rewrite one rack chain from its set form into its preset form."""
    lost = lost if lost is not None else Ledger()
    ptag = BRANCH_PRESET_TAG.get(tag)
    if not ptag:
        raise NeedsRackSupport(f"unknown rack chain type <{tag}>")
    f = direct(strip_tag(xml, tag))

    # The branch's display name lives in Name/EffectiveName in a set, but is a
    # plain attribute in a preset.
    name = ""
    if "Name" in f:
        n = direct(strip_tag(f["Name"], "Name"))
        m = re.search(r'Value="([^"]*)"', n.get("EffectiveName", ""))
        name = m.group(1) if m else ""

    here = f"{path}[{idx}]"
    devs = chain_devices(f["DeviceChain"]) if "DeviceChain" in f else []
    # The walk and a structural count disagreeing means the walk has gone
    # blind to a wrapper tag, which is exactly how every branch came out empty
    # before. Loud, not empty.
    if not devs and devices_present(xml):
        lost.drop(here, tag,
                  f"chain walk found no devices but the XML holds "
                  f"{devices_present(xml)} — unknown device-chain wrapper")
    entries = [p for p in (device_preset(t, x, i, lost, here)
                           for i, (t, x) in enumerate(devs)) if p]

    mixer = mixer_preset(f["MixerDevice"]) if "MixerDevice" in f else ""

    # A drum pad's note mapping is BranchInfo in a set and ZoneSettings in a
    # preset — same three fields, different tag. Losing it would collapse every
    # pad onto one note.
    if "BranchInfo" in f:
        zone = "<ZoneSettings>" + strip_tag(f["BranchInfo"], "BranchInfo") + "</ZoneSettings>"
    elif "ZoneSettings" in f:
        zone = f["ZoneSettings"]
    else:
        zone = EMPTY_ZONE if ptag != "AudioEffectBranchPreset" else ""

    colour = ""
    m = re.search(r'Value="(-?\d+)"', f.get("Color", ""))
    if m:
        colour = f'<DocumentColorIndex Value="{m.group(1)}" />'

    parts = [
        f'<{ptag} Id="{idx}">',
        f'<Name Value="{name.replace("&", "&amp;").replace("<", "&lt;").replace(chr(34), "&quot;")}" />',
        f.get("IsSoloed", '<IsSoloed Value="false" />'),
        "<DevicePresets>\n" + "\n".join(entries) + "\n</DevicePresets>",
        mixer,
        f.get("BranchSelectorRange", ""),
        f.get("SessionViewBranchWidth", ""),
        colour,
        f.get("AutoColored", ""),
        f.get("AutoColorScheme", ""),
        CLEAN_SOURCE_CONTEXT,
        zone,
        f"</{ptag}>",
    ]
    return "\n".join(p for p in parts if p)


def rack_preset(tag: str, xml: str, idx: int, tpl: "Template",
                lost: "Ledger | None" = None, path: str = "") -> str:
    """A rack as a nested <GroupDevicePreset>.

    Inside a set a rack carries its chains in a populated <Branches>; inside a
    preset that must be empty, with every chain restated under <BranchPresets>.
    """
    lost = lost if lost is not None else Ledger()
    here = f"{path}/{idx}:{tag}"
    f = direct(strip_tag(xml, tag))
    device = strip_set_only(xml, tag)
    for holder in ("Branches", "ReturnBranches"):
        if holder in f and f[holder].strip() not in (f"<{holder} />", f"<{holder}/>"):
            device = device.replace(f[holder], f"<{holder} />", 1)

    def convert(holder: str) -> list[str]:
        if holder not in f:
            return []
        inner = strip_tag(f[holder], holder).strip()
        return [branch_preset(t, inner[s:e], i, lost, f"{here}/{holder}")
                for i, (t, s, e) in enumerate(children(inner))]

    branches = convert("Branches")
    returns = convert("ReturnBranches")
    return (
        f'<GroupDevicePreset Id="{idx}">\n'
        f'<OverwriteProtectionNumber Value="3075" />\n'
        f"<Device>\n{device}\n</Device>\n"
        # PresetRef is required even though this rack was never loaded from a
        # file — omitting it is enough on its own for Live to reject the whole
        # preset. Empty, because the template's would claim an Instrument Rack
        # even where the device is a Drum Rack.
        "<PresetRef />\n"
        f"<BranchPresets>\n" + "\n".join(branches) + "\n</BranchPresets>\n"
        + (f"<ReturnBranchPresets>\n" + "\n".join(returns) + "\n</ReturnBranchPresets>\n"
           if returns else "<ReturnBranchPresets />\n")
        + "</GroupDevicePreset>"
    )


def device_preset(tag: str, xml: str, idx: int,
                  lost: "Ledger | None" = None, path: str = "") -> str | None:
    """One <DevicePresets> entry for a device as it appears inside a set.

    Returning None means the device could not be carried. Every such exit also
    records why in `lost`, because the callers used to filter the None out and
    write a chain that was quietly short a device.
    """
    lost = lost if lost is not None else Ledger()
    here = f"{path}/{idx}:{tag}"
    if tag in UNLOADABLE_IN_RACK:
        # Raising rather than dropping: the device is not the problem, the
        # whole document becomes unloadable. Staging carries the entire track
        # across instead, which is lossless and visibly a fallback.
        raise UnloadableInRack(
            f"Live will not load {tag} from a rack preset, so the whole preset "
            f"would be refused. Staged instead."
        )
    if tag in PLUGIN_TAGS:
        # The plug-in's own preset is already sitting inside the device.
        desc = element(xml, "PluginDesc")
        if not desc:
            lost.drop(here, tag, "no <PluginDesc> in the device")
            return None
        inside = xml[desc[0]:desc[1]]
        pr = element(inside, "Preset")
        if not pr:
            lost.drop(here, tag, "no <Preset> inside <PluginDesc>")
            return None
        # Take what's *inside* <Preset>, not the wrapper itself — the entry a
        # .adg wants is the <AuPreset> / <Vst3Preset> element on its own.
        frag = inside[pr[0]:pr[1]]
        body = re.sub(r"^<Preset(\s[^>]*?)?>", "", frag)
        body = body[:body.rindex("</Preset>")]
        for child_tag, s, e in children(body):
            if child_tag.endswith("Preset"):
                return re.sub(r'^<(\w+) Id="\d+"', r'<\1 Id="%d"' % idx,
                              body[s:e], count=1)
        lost.drop(here, tag, "<Preset> holds no *Preset element")
        return None

    if tag in RACK_TAGS:
        return rack_preset(tag, xml, idx, shared_template(), lost, path)

    # Leaf native devices are stored inside a preset exactly as they are inside
    # a set, so they only need the wrapper.
    return (
        f'<AbletonDevicePreset Id="{idx}">\n'
        f'<OverwriteProtectionNumber Value="3075" />\n'
        f"<Device>\n{xml}\n</Device>\n"
        f"</AbletonDevicePreset>"
    )


def track_devices(track_xml: str) -> list[tuple[str, str]]:
    """(tag, xml) for the track's own top-level devices, in chain order."""
    # The track's device list is the first <Devices> inside the inner
    # DeviceChain; any later one belongs to a rack and travels with it.
    outer = element(track_xml, "DeviceChain")
    if not outer:
        return []
    body = track_xml[outer[0]:outer[1]]
    r = element(body, "Devices")
    # Skip <Devices> that the sequencer sections may contribute.
    while r:
        frag = body[r[0]:r[1]]
        kids = children(re.sub(r"^<Devices(\s[^>]*?)?>|</Devices>$", "", frag).strip())
        if kids or "<Devices />" in frag or "<Devices/>" in frag:
            inner_src = re.sub(r"^<Devices(\s[^>]*?)?>|</Devices>$", "", frag).strip()
            return [(t, inner_src[s:e]) for t, s, e in kids]
        r = element(body, "Devices", r[1])
    return []


# --------------------------------------------------------------------------- #
# build
# --------------------------------------------------------------------------- #
def build(als: Path, track_id: str | None = None, title: str | None = None,
          out_dir: Path = STAGING, strict: bool = False,
          lost: "Ledger | None" = None) -> tuple[Path, list[str]]:
    """Write a .adg holding this track's device chain. Returns (path, devices).

    With `strict`, raises FidelityError rather than writing a preset that is
    missing any of the track's devices. Pass a `Ledger` to read back what was
    dropped either way.
    """
    if not als.exists() or als.stat().st_size == 0:
        raise ExtractError(
            f"{als.name} is missing or 0 bytes — Dropbox may have it online-only."
        )
    try:
        src = gzip.decompress(als.read_bytes()).decode("utf-8", "replace")
    except OSError as e:
        raise ExtractError(f"{als.name} is not a readable Live set ({e})")

    span, devices = None, []
    if track_id is None:
        # A curated export holds one layer; take the first track that has a
        # device chain on it.
        for m in TRACK_RE.finditer(src):
            if m.group(1) == "GroupTrack":
                continue
            end = src.find(f"</{m.group(1)}>", m.end())
            if end == -1:
                continue
            cand = (m.start(), end + len(f"</{m.group(1)}>"))
            d = track_devices(src[cand[0]:cand[1]])
            if d:
                span, devices = cand, d
                break
        if span is None:
            raise ExtractError(f"no track with devices found in {als.name}")
    else:
        for m in TRACK_RE.finditer(src):
            if m.group(2) == track_id:
                close = f"</{m.group(1)}>"
                end = src.find(close, m.end())
                if end == -1:
                    raise ExtractError(f"unterminated track {track_id}")
                span = (m.start(), end + len(close))
                break
        if span is None:
            raise ExtractError(f"track {track_id} is not in {als.name} — reindex and retry")
        devices = track_devices(src[span[0]:span[1]])
    if not devices:
        raise ExtractError("this layer has no devices on it — nothing to load")

    tpl = Template()
    lost = lost if lost is not None else Ledger()
    entries, names = [], []
    for i, (tag, xml) in enumerate(devices):
        p = device_preset(tag, xml, i, lost, "")
        if p:
            entries.append(p)
            names.append(tag)
    if not entries:
        raise ExtractError(
            "none of this layer's devices could be converted "
            f"({', '.join(t for t, _ in devices)})"
        )
    # A half-converted preset is worse than none: it looks like it worked, so
    # it gets used, and the missing devices surface much later. Callers that
    # have a lossless fallback (staging the whole track) ask for strict.
    if strict and lost:
        raise FidelityError(lost.summary())

    name = safe_name(title or f"{als.stem}-{track_id}")
    doc = (
        tpl.header
        + "<GroupDevicePreset>\n"
        + '<OverwriteProtectionNumber Value="3075" />\n'
        + tpl.rack_device + "\n"
        + tpl.preset_ref + "\n"
        + "<BranchPresets>\n"
        + tpl.branch_open.replace("</Name>", "</Name>", 1)
        + "<DevicePresets>\n" + "\n".join(entries) + "\n</DevicePresets>"
        + tpl.branch_tail
        + "</InstrumentBranchPreset>\n"
        + "</BranchPresets>\n"
        + tpl.return_branches + "\n"
        + "</GroupDevicePreset>\n</Ableton>\n"
    )
    doc = re.sub(r'(<InstrumentBranchPreset[^>]*>\s*<Name Value=")[^"]*(")',
                 lambda m: m.group(1) + name.replace('"', "'") + m.group(2), doc, count=1)

    out_dir.mkdir(parents=True, exist_ok=True)
    blob = repoint_samples(doc.encode("utf-8"), als.parent, out_dir)
    dest = out_dir / f"{name}.adg"
    payload = gzip.compress(blob, 1)
    if not (dest.exists() and dest.read_bytes() == payload):
        dest.write_bytes(payload)
    return dest, names


def main() -> None:
    if len(sys.argv) < 3:
        print("usage: make_adg.py <set.als> <track_id> [title]", file=sys.stderr)
        raise SystemExit(2)
    dest, names = build(Path(sys.argv[1]), sys.argv[2],
                        sys.argv[3] if len(sys.argv) > 3 else None)
    print(f"{dest}\n  {len(names)} devices: {', '.join(names)}")


if __name__ == "__main__":
    main()
