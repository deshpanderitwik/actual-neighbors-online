#!/usr/bin/env python3
"""
crate server — serves the browser UI, streams sample previews, and loads
layers straight into the running Live set.

Talks to Ableton over the AbletonMCP remote script's socket (127.0.0.1:9877),
which speaks {"type": ..., "params": {...}} -> {"status": ..., "result": ...}.
Stdlib only; no install step.
"""
from __future__ import annotations

import json
import mimetypes
import os
import re
import socket
import subprocess
import sys
import threading
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import config  # noqa: E402
import extract_track  # noqa: E402
import make_adg  # noqa: E402

HERE = Path(__file__).resolve().parent
INDEX_FILE = config.INDEX_FILE
APP_FILE = HERE / "app.html"
PANEL_FILE = HERE / "panel.html"

LIVE_HOST, LIVE_PORT = "127.0.0.1", 9877
# Audio may only be streamed from inside these roots.
AUDIO_ROOTS = [Path(r) for r in config.load()["audio_roots"]]

_index_lock = threading.Lock()
_reindex_state = {"running": False, "log": "", "ok": None}


# --------------------------------------------------------------------------- #
# Ableton bridge
# --------------------------------------------------------------------------- #
class LiveError(RuntimeError):
    pass


class RejectedByLive(LiveError):
    """Live accepted the preset and then loaded nothing from it.

    Distinct from LiveError because it has a good fallback: the conversion is
    fine (the offline rung proves the preset holds every device), Live simply
    refuses this document. Staging the track instead still gets the layer
    across, so this should not surface as a failure.
    """


def live(cmd: str, params: dict | None = None, timeout: float = 20.0) -> dict:
    """One request/response round-trip to the remote script."""
    try:
        s = socket.create_connection((LIVE_HOST, LIVE_PORT), timeout=timeout)
    except OSError as e:
        raise LiveError(f"Live is not reachable on {LIVE_PORT} ({e}). "
                        "Is the set open with the AbletonMCP control surface enabled?")
    try:
        s.sendall(json.dumps({"type": cmd, "params": params or {}}).encode())
        buf = b""
        while True:
            chunk = s.recv(65536)
            if not chunk:
                break
            buf += chunk
            try:
                reply = json.loads(buf)
            except json.JSONDecodeError:
                continue
            if reply.get("status") == "error":
                raise LiveError(reply.get("message", "unknown error"))
            return reply.get("result", {})
        raise LiveError("Live closed the connection without replying")
    finally:
        s.close()


def lom_get(path: str):
    return live("lom_get", {"path": path}).get("value")


def lom_get_batch(paths: list[str]) -> list:
    return live("lom_get_batch", {"paths": paths}).get("results", [])


def lom_call(path: str, args: list | None = None, timeout: float = 20.0):
    return live("lom_call", {"path": path, "args": args or []}, timeout=timeout)


def lom_set(path: str, value):
    return live("lom_set", {"path": path, "value": value})


# --------------------------------------------------------------------------- #
# Resolving a file on disk to a browser item path
# --------------------------------------------------------------------------- #
# The remote script's own load_browser_item can't help here: it looks a URI up
# by walking Instruments/Sounds/Drums/Audio Effects/MIDI Effects only, and
# never descends into Places, which is where this library lives. So walk
# user_folders by name and build an @-path that lom_call can resolve.
_browser_cache: dict[str, str] = {}


def browser_path_for(file_path: Path) -> str:
    """'@app.browser.user_folders[i].children[j]…' for a file inside a Place."""
    key = str(file_path)
    if key in _browser_cache:
        return _browser_cache[key]

    n_places = (lom_get("app.browser.user_folders") or {}).get("count", 0)
    names = [r.get("value") for r in lom_get_batch(
        [f"app.browser.user_folders[{i}].name" for i in range(n_places)])]

    # Each candidate is a folder on disk paired with where Live keeps it.
    # Places are matched by the deepest parent directory bearing the Place's
    # name, so "AN" resolves to ~/Dropbox/AN. The User Library is always
    # present in Live's browser, so staging there needs nothing set up.
    roots: list[tuple[Path, str]] = []
    for i, place in enumerate(names):
        if not place:
            continue
        hit = next((p for p in file_path.parents if p.name == place), None)
        if hit:
            roots.append((hit, f"app.browser.user_folders[{i}]"))
    roots.append((config.USER_LIBRARY, "app.browser.user_library"))

    for root, base in roots:
        try:
            rel = file_path.relative_to(root)
        except ValueError:
            continue

        path = base
        for part in rel.parts:
            # Live's browser caches each folder's listing and rescans lazily, so
            # a file written a moment ago is often not there on the first look.
            j = None
            for attempt in range(30):
                count = (lom_get(f"{path}.children") or {}).get("count", 0)
                kids = ([r.get("value") for r in lom_get_batch(
                    [f"{path}.children[{k}].name" for k in range(count)])]
                    if count else [])
                if part in kids:
                    j = kids.index(part)
                    break
                j = next((k for k, nm in enumerate(kids)
                          if nm and Path(nm).stem == Path(part).stem), None)
                if j is not None:
                    break
                time.sleep(0.6)
            if j is None:
                raise LiveError(
                    f"Live's browser still doesn't list '{part}' under {path}. "
                    "Clicking the folder in Live's sidebar forces a rescan.")
            path = f"{path}.children[{j}]"
        _browser_cache[key] = "@" + path
        return "@" + path

    raise LiveError(
        f"{file_path} is not inside Live's User Library or any folder in Places"
    )


# --------------------------------------------------------------------------- #
# Loading a layer
# --------------------------------------------------------------------------- #
_extract_cache: dict[tuple[str, str], Path] = {}


PRESET_EXT = (".adg", ".adv")

# Where a layer belongs in the template, by the taxonomy tag the indexer gave
# it. First group that exists in the open set wins.
GROUP_FOR_TAG = {
    "kick": [">>> KICKS"],
    "snare": [">>> SNARES"],
    "clap": [">>> SNARES"],
    "hat": [">>> HIGH PERC"],
    "cymbal": [">>> HIGH PERC"],
    "perc": [">>> LOW PERC"],
    "tom": [">>> LOW PERC"],
    "break": [">>> RACKS"],
    "drums": [">>> RACKS"],
    "808": ["SUB", "BASS"],
    "bass": ["BASS"],
    "vocal": ["VOX"],
}


def unfold_ancestors(idx: int) -> None:
    """Open every group above a track.

    Live refuses to select a track inside a folded group ("The given Track is
    invisible"), and a track can't be loaded onto without being selected.
    """
    n = (lom_get("tracks") or {}).get("count", 0)
    names = [r.get("value") for r in lom_get_batch(
        [f"tracks[{i}].name" for i in range(n)])]
    cur, hops = idx, 0
    while hops < 8:
        g = lom_get(f"tracks[{cur}].group_track")
        if not isinstance(g, dict) or g.get("name") not in names:
            return
        gi = names.index(g["name"])
        try:
            lom_set(f"tracks[{gi}].fold_state", 0)
        except LiveError:
            pass
        cur, hops = gi, hops + 1


def insertion_index(entry: dict) -> tuple[int, str | None]:
    """Where to create the track, and the group it will land in.

    A track created at group_index + 1 joins that group automatically; created
    just past the group's last member it stays outside. So aim for the slot
    right after the group header.

    Destination is the layer's *own* group in the project it came from, deepest
    first — a track that lived in DRUMS / >>> HIGH PERC belongs in >>> HIGH PERC
    here. That beats guessing from the name, because it's where you put it. The
    tag only stands in when there's no group to go on, as for a library export.
    """
    n = (lom_get("tracks") or {}).get("count", 0)
    names = [r.get("value") for r in lom_get_batch(
        [f"tracks[{i}].name" for i in range(n)])]
    lower = {(nm or "").strip().lower(): i for i, nm in enumerate(names)}

    wanted: list[str] = list(reversed(entry.get("groups") or []))
    wanted += GROUP_FOR_TAG.get(entry.get("tag") or "", [])
    if entry.get("category"):
        wanted.append(entry["category"])

    for cand in wanted:
        i = lower.get(cand.strip().lower())
        if i is not None and lom_get(f"tracks[{i}].is_foldable"):
            return i + 1, names[i]
    return n, None


def preset_for(entry: dict) -> tuple[Path, list[str]]:
    """A .adg Live can load for this layer, building one if needed.

    Live's API will not import a .als — its browser reports one as loadable and
    `browser.load_item` returns cleanly, but nothing arrives (verified with a
    track selected and with a clip slot highlighted, and the same for .alc).
    Only device presets load, so anything else is converted first.
    """
    p = Path(entry.get("file", ""))
    if p.suffix.lower() in PRESET_EXT:
        return p, []
    track_id = entry["id"].rsplit(":", 1)[-1] if entry.get("source") == "project" else None
    # strict: refuse to write a preset that is missing any of the track's
    # devices. A thinned rack is the worst outcome — it looks like it worked,
    # so it gets used, and the missing half surfaces much later. FidelityError
    # is an ExtractError, so /api/load already falls back to staging, which
    # carries the whole track losslessly and is visibly a fallback.
    return make_adg.build(p, track_id, entry.get("title"), strict=True)


def stage_layer(entry: dict) -> Path:
    """Put this layer in the staging folder, ready to drag into the set."""
    als = Path(entry["file"])
    try:
        if entry.get("source") == "project":
            track_id = entry["id"].rsplit(":", 1)[-1]
            key = (str(als), track_id)
            hit = _extract_cache.get(key)
            if hit and hit.exists():
                return hit
            dest = extract_track.extract(als, track_id, entry.get("title"))
            _extract_cache[key] = dest
            return dest
        return extract_track.stage_set(als, entry.get("title"))
    except extract_track.ExtractError as e:
        raise LiveError(str(e))


def load_layer(entry: dict, rename: bool = True) -> dict:
    """Build a preset for the layer and load it onto a new track in its group."""
    preset, converted = preset_for(entry)
    if not preset.exists():
        raise LiveError(f"missing file: {preset}")

    # Written a moment ago, so Live's browser may not list it yet.
    item = browser_path_for(preset)

    idx, group = insertion_index(entry)
    before = (lom_get("tracks") or {}).get("count", 0)
    lom_call("create_midi_track", [idx])
    if (lom_get("tracks") or {}).get("count", 0) <= before:
        raise LiveError("Live did not create the track")

    def discard() -> None:
        try:
            lom_set("view.selected_track", "@tracks[0]")
            lom_call("delete_track", [idx])
        except LiveError:
            pass

    try:
        unfold_ancestors(idx)
        lom_set("view.selected_track", f"@tracks[{idx}]")
        lom_call("app.browser.load_item", [item], timeout=90)
    except LiveError:
        discard()
        raise

    devices = (lom_get(f"tracks[{idx}].devices") or {}).get("count", 0)
    if devices == 0:
        discard()
        raise RejectedByLive(
            f"Live accepted {preset.name} but loaded nothing onto the track — "
            "it is rejecting the document. Staged instead."
        )

    if rename:
        try:
            lom_set(f"tracks[{idx}].name", (entry.get("title") or preset.stem)[:60])
        except LiveError:
            pass

    g = lom_get(f"tracks[{idx}].group_track")
    return {
        "track_index": idx,
        "track_name": lom_get(f"tracks[{idx}].name"),
        "devices": devices,
        "group": (g or {}).get("name") if isinstance(g, dict) else None,
        "intended_group": group,
        "converted": converted,
        "file": str(preset),
    }


# --------------------------------------------------------------------------- #
# index access
# --------------------------------------------------------------------------- #
def read_index() -> dict:
    with _index_lock:
        if not INDEX_FILE.exists():
            return {"entries": [], "counts": {}, "built": 0}
        return json.loads(INDEX_FILE.read_text())


def entry_by_id(eid: str) -> dict | None:
    for e in read_index().get("entries", []):
        if e.get("id") == eid:
            return e
    return None


def reindex(min_project: int) -> None:
    def run():
        _reindex_state.update(running=True, log="", ok=None)
        try:
            p = subprocess.run(
                [sys.executable, "-I", str(HERE / "index_als.py"),
                 str(min_project), str(INDEX_FILE)],
                capture_output=True, text=True, timeout=3600,
            )
            _reindex_state.update(log=(p.stderr or p.stdout)[-4000:], ok=(p.returncode == 0))
        except Exception as e:
            _reindex_state.update(log=str(e), ok=False)
        finally:
            _reindex_state["running"] = False

    threading.Thread(target=run, daemon=True).start()


# --------------------------------------------------------------------------- #
# HTTP
# --------------------------------------------------------------------------- #
def allowed_audio(p: Path) -> bool:
    try:
        rp = p.resolve()
    except OSError:
        return False
    return any(str(rp).startswith(str(r.resolve()) + os.sep) for r in AUDIO_ROOTS)


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "crate"

    def log_message(self, fmt, *a):  # quiet
        pass

    # -- helpers ----------------------------------------------------------- #
    def _send(self, code: int, body: bytes, ctype: str, extra: dict | None = None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, obj, code: int = 200):
        self._send(code, json.dumps(obj).encode(), "application/json")

    def _fail(self, msg: str, code: int = 400):
        self._json({"error": msg}, code)

    # -- GET --------------------------------------------------------------- #
    def do_GET(self):
        u = urllib.parse.urlparse(self.path)
        q = urllib.parse.parse_qs(u.query)
        route = u.path

        # The panel is what the menu bar opens; the full two-pane browser is
        # still there for digging on a big screen.
        if route in ("/", "/index.html", "/panel"):
            if not PANEL_FILE.exists():
                return self._fail("panel.html is missing", 500)
            return self._send(200, PANEL_FILE.read_bytes(), "text/html; charset=utf-8",
                              {"Cache-Control": "no-store"})

        if route == "/full":
            if not APP_FILE.exists():
                return self._fail("app.html is missing", 500)
            return self._send(200, APP_FILE.read_bytes(), "text/html; charset=utf-8",
                              {"Cache-Control": "no-store"})

        if route.startswith("/assets/"):
            # Fonts shared with an-media-player, so both read as one family.
            p = (HERE / route.lstrip("/")).resolve()
            if not str(p).startswith(str((HERE / "assets").resolve()) + os.sep):
                return self._fail("outside assets", 403)
            if not p.is_file():
                return self._fail("not found", 404)
            ctype = mimetypes.guess_type(p.name)[0] or "application/octet-stream"
            if p.suffix.lower() == ".ttf":
                ctype = "font/ttf"
            return self._send(200, p.read_bytes(), ctype,
                              {"Cache-Control": "max-age=86400"})

        if route == "/index.json":
            return self._send(200, json.dumps(read_index()).encode(),
                              "application/json", {"Cache-Control": "no-store"})

        if route == "/api/status":
            # `version` is what the shell checks before adopting this server.
            # An older build does not report one, which is itself the signal
            # that it must be replaced rather than reused.
            out = {"version": config.VERSION,
                   "index": read_index().get("counts", {}),
                   "built": read_index().get("built", 0),
                   "reindex": _reindex_state}
            try:
                info = live("get_session_info", timeout=5)
                out["live"] = {"ok": True, "tracks": info.get("track_count"),
                               "tempo": info.get("tempo")}
            except LiveError as e:
                out["live"] = {"ok": False, "error": str(e)}
            return self._json(out)

        if route == "/audio":
            raw = (q.get("path") or [""])[0]
            if not raw:
                return self._fail("path required")
            p = Path(raw)
            if not allowed_audio(p):
                return self._fail("path outside the allowed roots", 403)
            if not p.is_file():
                return self._fail("not found", 404)
            return self._serve_file(p)

        return self._fail("not found", 404)

    def _serve_file(self, p: Path):
        """Byte-range aware, so the waveform can seek."""
        size = p.stat().st_size
        ctype = mimetypes.guess_type(p.name)[0] or "application/octet-stream"
        if p.suffix.lower() in (".aif", ".aiff"):
            ctype = "audio/aiff"
        rng = self.headers.get("Range")
        start, end = 0, size - 1
        code = 200
        if rng:
            m = re.match(r"bytes=(\d*)-(\d*)", rng)
            if m:
                if m.group(1):
                    start = int(m.group(1))
                if m.group(2):
                    end = min(int(m.group(2)), size - 1)
                if start > end or start >= size:
                    self.send_response(416)
                    self.send_header("Content-Range", f"bytes */{size}")
                    self.end_headers()
                    return
                code = 206
        length = end - start + 1
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(length))
        if code == 206:
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.end_headers()
        if self.command == "HEAD":
            return
        with open(p, "rb") as f:
            f.seek(start)
            left = length
            while left > 0:
                chunk = f.read(min(262144, left))
                if not chunk:
                    break
                self.wfile.write(chunk)
                left -= len(chunk)

    # -- POST -------------------------------------------------------------- #
    def do_POST(self):
        route = urllib.parse.urlparse(self.path).path
        try:
            n = int(self.headers.get("Content-Length") or 0)
            body = json.loads(self.rfile.read(n) or b"{}")
        except Exception:
            return self._fail("bad json")

        if route == "/api/load":
            eid = body.get("id")
            e = entry_by_id(eid) if eid else None
            if not e:
                return self._fail(f"unknown layer: {eid}", 404)
            # A project layer is a track inside a 40-track set; prefer its
            # exported twin, which is a single loadable file.
            target = dict(e)
            if body.get("use_twin") and e.get("twin"):
                tw = entry_by_id(e["twin"]["id"])
                if tw:
                    target = dict(tw)
            try:
                return self._json({"ok": True, "mode": "loaded", **load_layer(target)})
            except (make_adg.NeedsRackSupport, extract_track.ExtractError,
                    RejectedByLive) as ex:
                # Not convertible into a preset — fall back to the drag path
                # rather than failing, so the click still gets them somewhere.
                try:
                    dest = stage_layer(target)
                except LiveError as ex2:
                    return self._fail(str(ex2), 502)
                return self._json({
                    "ok": True, "mode": "staged", "name": dest.name,
                    "reason": str(ex),
                    "browser": "Places ▸ AN ▸ 04 Samples ▸ _explorer-staging",
                })
            except LiveError as ex:
                return self._fail(str(ex), 502)

        if route == "/api/stage":
            eid = body.get("id")
            e = entry_by_id(eid) if eid else None
            if not e:
                return self._fail(f"unknown layer: {eid}", 404)
            try:
                dest = stage_layer(e)
            except LiveError as ex:
                return self._fail(str(ex), 502)
            if body.get("reveal"):
                subprocess.run(["open", "-R", str(dest)], check=False)
            return self._json({
                "ok": True,
                "path": str(dest),
                "name": dest.name,
                "browser": "Places ▸ AN ▸ 04 Samples ▸ _explorer-staging",
            })

        if route == "/api/reveal":
            p = Path(body.get("path", ""))
            if not p.exists():
                return self._fail("not found", 404)
            subprocess.run(["open", "-R", str(p)], check=False)
            return self._json({"ok": True})

        if route == "/api/quit":
            # So a newer shell can retire this server without resorting to a
            # signal. A build old enough not to have this is killed by pid
            # instead; both paths exist because the first upgrade to carry
            # this endpoint has to replace a server that lacks it.
            self._json({"ok": True, "version": config.VERSION})
            threading.Thread(target=self.server.shutdown, daemon=True).start()
            return

        if route == "/api/reindex":
            if _reindex_state["running"]:
                return self._json({"ok": False, "running": True})
            reindex(int(body.get("min_project", config.load()["min_project"])))
            return self._json({"ok": True, "running": True})

        return self._fail("not found", 404)


def main() -> None:
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 7788
    srv = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    print(f"instrument explorer {config.VERSION} on http://127.0.0.1:{port}")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
