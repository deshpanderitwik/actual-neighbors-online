# handlers.py — hot-reloadable LOM primitive layer.
#
# This module is intentionally kept small and self-contained so that
# `importlib.reload(handlers)` from the dispatcher in __init__.py picks up
# edits without a full Ableton restart. Do not store state at module scope
# that needs to survive reloads.

from __future__ import absolute_import, print_function, unicode_literals
import re

try:
    import Live
except ImportError:
    Live = None

# A path is a sequence of dotted attributes, bracketed integer indices, and
# optional call groups. Call arguments may be primitives or @-prefixed paths
# that resolve to LOM objects from the same root — this is the only way to
# pass live objects (e.g. a DeviceParameter) into LOM methods over JSON.
# Examples:
#   song.tempo
#   song.tracks[0].clip_slots[2].clip.name
#   song.cue_points[0].time
#   song.view.selected_track.name
#   tracks[13].arrangement_clips[0].automation_envelope(@tracks[13].devices[0].parameters[1]).insert_step(0.0, 1.0, 136.0)
_TOKEN_RE = re.compile(r"(\w+)|\[(-?\d+)\]|\(([^()]*)\)")


def _tokenize(path):
    """Split a path into ('attr', name) / ('index', i) / ('call', argstr) tuples."""
    if not path:
        return []
    tokens = []
    pos = 0
    for m in _TOKEN_RE.finditer(path):
        if m.start() != pos and not (path[pos] == '.' and m.start() == pos + 1):
            # Allow only '.' between tokens (and bracket boundaries).
            # We don't fail hard here; whitespace/garbage gets ignored.
            pass
        attr, idx, callargs = m.groups()
        if attr is not None:
            tokens.append(('attr', attr))
        elif idx is not None:
            tokens.append(('index', int(idx)))
        else:
            tokens.append(('call', callargs))
        pos = m.end()
    return tokens


def _parse_call_args(argstr, root):
    """Parse a call group's argument string into Python values.

    Supported: ints, floats, true/false, none/null, 'quoted'/"quoted" strings
    (no embedded commas), and @path references resolved from `root`.
    """
    args = []
    s = argstr.strip()
    if not s:
        return args
    for part in s.split(','):
        p = part.strip()
        low = p.lower()
        if p.startswith('@'):
            args.append(_resolve(root, p[1:]))
        elif low in ('true', 'false'):
            args.append(low == 'true')
        elif low in ('none', 'null'):
            args.append(None)
        elif len(p) >= 2 and p[0] in '\'"' and p[-1] == p[0]:
            args.append(p[1:-1])
        else:
            try:
                args.append(int(p))
            except ValueError:
                args.append(float(p))
    return args


def _resolve(root, path):
    """Walk path from root to leaf and return the leaf value.

    Raises ValueError with the consumed prefix on any access failure so the
    caller can see exactly where the path broke.
    """
    obj = root
    tokens = _tokenize(path)
    # An 'app' / 'application' first token roots the walk at the Live
    # Application instead of the Song, e.g. app.browser.load_item(...).
    if tokens and tokens[0][0] == 'attr' and tokens[0][1] in ('app', 'application'):
        obj = Live.Application.get_application()
        tokens = tokens[1:]
    consumed = []
    for kind, val in tokens:
        try:
            if kind == 'attr':
                obj = getattr(obj, val)
                consumed.append(val)
            elif kind == 'call':
                obj = obj(*_parse_call_args(val, root))
                consumed.append('(%s)' % val)
            else:
                obj = obj[val]
                consumed.append('[%d]' % val)
        except Exception as e:
            raise ValueError(
                "Path resolution failed after '%s' on %s %r: %s"
                % ('.'.join(consumed), kind, val, str(e))
            )
    return obj


def _resolve_parent(root, path):
    """Return (parent_obj, last_token) so callers can setattr or setitem."""
    tokens = _tokenize(path)
    if not tokens:
        raise ValueError("Empty path")
    obj = root
    if tokens and tokens[0][0] == 'attr' and tokens[0][1] in ('app', 'application'):
        obj = Live.Application.get_application()
        tokens = tokens[1:]
        if not tokens:
            raise ValueError("Cannot assign to the application root")
    for kind, val in tokens[:-1]:
        if kind == 'attr':
            obj = getattr(obj, val)
        elif kind == 'call':
            obj = obj(*_parse_call_args(val, root))
        else:
            obj = obj[val]
    return obj, tokens[-1]


# JSON-friendly reflection of any value, LOM or Python.
_PRIMITIVES = (type(None), bool, int, float, str)
try:
    _PRIMITIVES = _PRIMITIVES + (unicode,)  # py2 compat
except NameError:
    pass


def _reflect(value, depth=0, max_depth=2):
    """Return a JSON-serializable view of `value`.

    - Primitives pass through.
    - Lists/tuples recurse up to max_depth, then collapse to a count.
    - LOM objects return {__lom__: True, type, name?, count?}.
    """
    if isinstance(value, _PRIMITIVES):
        return value
    if isinstance(value, (tuple, list)):
        if depth >= max_depth:
            return {"__lom__": True, "type": "list", "count": len(value)}
        return [_reflect(v, depth + 1, max_depth) for v in value]
    if isinstance(value, dict):
        if depth >= max_depth:
            return {"__lom__": True, "type": "dict", "count": len(value)}
        return {str(k): _reflect(v, depth + 1, max_depth) for k, v in value.items()}

    info = {"__lom__": True, "type": type(value).__name__}
    # Try a few common informational attrs without triggering LOM exceptions
    for attr in ("name",):
        try:
            v = getattr(value, attr)
            if isinstance(v, _PRIMITIVES):
                info[attr] = v
        except Exception:
            pass
    try:
        info["count"] = len(value)
    except Exception:
        pass
    # If callable, mark it so server.py can decide to lom_call instead
    if callable(value):
        info["callable"] = True
    return info


# ---- public primitives -----------------------------------------------------
# Each takes (song, params) and returns a JSON-serializable dict. Errors raise
# normally; the dispatcher wraps them into the response envelope.

def lom_get(song, params):
    path = params.get("path", "")
    if not path:
        raise ValueError("lom_get requires 'path'")
    value = _resolve(song, path)
    return {"path": path, "value": _reflect(value)}


def lom_get_batch(song, params):
    paths = params.get("paths", []) or []
    results = []
    for p in paths:
        try:
            results.append({"path": p, "value": _reflect(_resolve(song, p))})
        except Exception as e:
            results.append({"path": p, "error": str(e)})
    return {"results": results, "count": len(results)}


def lom_set(song, params):
    path = params.get("path", "")
    if not path:
        raise ValueError("lom_set requires 'path'")
    if "value" not in params:
        raise ValueError("lom_set requires 'value'")
    value = params["value"]
    # '@'-prefixed string values resolve as LOM paths, mirroring lom_call args,
    # so object-valued properties (selected_track, highlighted_clip_slot, ...)
    # can be assigned over JSON.
    if isinstance(value, str) and value.startswith('@'):
        value = _resolve(song, value[1:])
    parent, (kind, key) = _resolve_parent(song, path)
    if kind == 'attr':
        setattr(parent, key, value)
    else:
        parent[key] = value
    return {"ok": True, "path": path}


def _make_warp_marker(d):
    """Build a Live.Clip.WarpMarker from {'sample_time': s, 'beat_time': b}."""
    try:
        return Live.Clip.WarpMarker(sample_time=d['sample_time'], beat_time=d['beat_time'])
    except Exception:
        m = Live.Clip.WarpMarker()
        m.sample_time = d['sample_time']
        m.beat_time = d['beat_time']
        return m


def lom_call(song, params):
    # String args prefixed with '@' are resolved as LOM paths so live objects
    # (clips, device parameters, ...) can be passed to methods over JSON.
    # IMPORTANT: anything that mutates Live state must go through lom_call,
    # never a call-group inside a lom_get path — lom_get runs on the socket
    # thread and mutating the document there hard-crashes Live.
    path = params.get("path", "")
    args = params.get("args", []) or []
    kwargs = params.get("kwargs", {}) or {}
    if not path:
        raise ValueError("lom_call requires 'path'")
    fn = _resolve(song, path)
    if not callable(fn):
        raise ValueError("Path '%s' is not callable" % path)

    def _coerce(a):
        if isinstance(a, str) and a.startswith('@'):
            return _resolve(song, a[1:])
        if isinstance(a, dict) and set(a) == {'sample_time', 'beat_time'}:
            return _make_warp_marker(a)
        return a

    # kwargs['__batch__'] = [[args...], ...] invokes fn once per arg-list in a
    # single round-trip (e.g. hundreds of envelope insert_step calls).
    batch = kwargs.pop('__batch__', None)
    if batch is not None:
        count = 0
        for one in batch:
            fn(*[_coerce(a) for a in one])
            count += 1
        return {"ok": True, "path": path, "count": count}

    result = fn(*[_coerce(a) for a in args], **kwargs)
    return {"ok": True, "path": path, "result": _reflect(result)}
