#!/usr/bin/env python3
"""
Pull a single track out of a saved Live set into its own one-track .als, so it
can be loaded into the open set through Live's browser.

Live offers no way to reach inside a saved set: a .als shows up in the browser
as one opaque loadable item with no children, so "load just this track" has to
be done by rewriting the file.

The rewrite is deliberately surgical. Rather than building a set from scratch
(every Id, send and routing would have to be invented), it takes the original
document and deletes the byte ranges of every track except the wanted one.
Everything else — tempo, return tracks, master chain, the schema version Live
expects — stays exactly as Live wrote it. Track elements are siblings under
<Tracks> and never nest, so each one is a single contiguous span.
"""
from __future__ import annotations

import gzip
import html
import os
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import index_als  # noqa: E402
from index_als import AN, resolve_sample  # noqa: E402

STAGING = index_als._CFG["staging"]

# Tracks that live under <Tracks>. ReturnTrack is deliberately absent: the kept
# track's sends address returns positionally, so removing them breaks routing.
TRACK_RE = re.compile(rb'<(AudioTrack|MidiTrack|GroupTrack) Id="(\d+)"')
GROUP_ID_RE = re.compile(rb'<TrackGroupId Value="-?\d+" />')


class ExtractError(RuntimeError):
    pass


def safe_name(s: str) -> str:
    s = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "-", s).strip(" .")
    return (s or "layer")[:70]


FILEREF_RE = re.compile(rb"<FileRef>.*?</FileRef>", re.S)
RELPATH_RE = re.compile(rb'(<RelativePath Value=")([^"]*)(")')
ABSPATH_RE = re.compile(rb'(<Path Value=")([^"]*)(")')


def _xml_attr(s: str) -> bytes:
    return (s.replace("&", "&amp;").replace("<", "&lt;")
             .replace(">", "&gt;").replace('"', "&quot;")).encode()


def repoint_samples(blob: bytes, src_dir: Path, out_dir: Path) -> bytes:
    """Rewrite every sample reference so it still resolves from `out_dir`.

    A set's RelativePath is relative to the set's own folder, so moving the
    file breaks every sample link. The absolute Path is no help either — these
    sets were written on another machine. So resolve each reference against the
    original project, then write both forms back pointing at the real file.
    """
    def fix(m: re.Match) -> bytes:
        block = m.group(0)
        rel_m, abs_m = RELPATH_RE.search(block), ABSPATH_RE.search(block)
        rel = rel_m.group(2).decode("utf-8", "replace") if rel_m else None
        ab = abs_m.group(2).decode("utf-8", "replace") if abs_m else None
        if not (rel or ab):
            return block
        found = resolve_sample(
            html.unescape(rel) if rel else None,
            html.unescape(ab) if ab else None,
            [src_dir, src_dir.parent, AN],
        )
        if not found:
            return block
        if abs_m:
            block = ABSPATH_RE.sub(
                lambda a: a.group(1) + _xml_attr(str(found)) + a.group(3), block, count=1)
        if rel_m:
            new_rel = os.path.relpath(str(found), str(out_dir))
            block = RELPATH_RE.sub(
                lambda a: a.group(1) + _xml_attr(new_rel) + a.group(3), block, count=1)
        return block

    return FILEREF_RE.sub(fix, blob)


def track_spans(raw: bytes) -> list[tuple[int, int, str, str]]:
    """(start, end, tag, id) for every track element, in document order."""
    out = []
    for m in TRACK_RE.finditer(raw):
        tag = m.group(1)
        close = b"</" + tag + b">"
        end = raw.find(close, m.end())
        if end == -1:
            raise ExtractError(f"unterminated <{tag.decode()}> at byte {m.start()}")
        out.append((m.start(), end + len(close), tag.decode(), m.group(2).decode()))
    return out


def extract(als: Path, track_id: str, title: str | None = None,
            out_dir: Path = STAGING) -> Path:
    """Write a one-track copy of `als` and return its path."""
    if not als.exists():
        raise ExtractError(f"missing set: {als}")
    if als.stat().st_size == 0:
        raise ExtractError(
            f"{als.name} is 0 bytes — Dropbox probably has it online-only. "
            "Open the folder in Finder to download it, then reindex."
        )
    try:
        raw = gzip.decompress(als.read_bytes())
    except OSError as e:
        raise ExtractError(f"{als.name} is not a readable Live set ({e})")

    spans = track_spans(raw)
    if not spans:
        raise ExtractError(f"no tracks found in {als.name}")
    target = next((s for s in spans if s[3] == track_id), None)
    if target is None:
        raise ExtractError(f"track id {track_id} is not in {als.name} — reindex and retry")

    out = bytearray()
    cursor = 0
    for start, end, _tag, tid in spans:
        out += raw[cursor:start]
        if tid == track_id:
            # Reparent to the top level; its group is about to disappear.
            out += GROUP_ID_RE.sub(b'<TrackGroupId Value="-1" />', raw[start:end], count=1)
        cursor = end
    out += raw[cursor:]

    out = repoint_samples(bytes(out), als.parent, out_dir)

    out_dir.mkdir(parents=True, exist_ok=True)
    name = safe_name(title or f"{als.stem}-{track_id}")
    dest = out_dir / f"{name}.als"
    payload = gzip.compress(bytes(out), 1)

    # Re-carving the same track every time would litter the staging folder with
    # near-identical files and force Live to rescan it on each load.
    if dest.exists() and dest.read_bytes() == payload:
        return dest
    n = 2
    while dest.exists():
        if dest.read_bytes() == payload:
            return dest
        dest = out_dir / f"{name}-{n}.als"
        n += 1
    dest.write_bytes(payload)
    return dest


def stage_set(als: Path, title: str | None = None,
              out_dir: Path = STAGING) -> Path:
    """Copy a ready-made export into staging, repointing its samples.

    A curated export in 04 Instruments may keep its samples in a sibling
    Samples/ folder, so a plain copy would break them.
    """
    if not als.exists() or als.stat().st_size == 0:
        raise ExtractError(f"{als.name} is missing or empty")
    try:
        raw = gzip.decompress(als.read_bytes())
    except OSError as e:
        raise ExtractError(f"{als.name} is not a readable Live set ({e})")

    out_dir.mkdir(parents=True, exist_ok=True)
    payload = gzip.compress(repoint_samples(raw, als.parent, out_dir), 1)
    dest = out_dir / f"{safe_name(title or als.stem)}.als"
    if dest.exists() and dest.read_bytes() == payload:
        return dest
    dest.write_bytes(payload)
    return dest


def main() -> None:
    if len(sys.argv) < 3:
        print("usage: extract_track.py <set.als> <track_id> [title]", file=sys.stderr)
        raise SystemExit(2)
    title = sys.argv[3] if len(sys.argv) > 3 else None
    dest = extract(Path(sys.argv[1]), sys.argv[2], title)
    src = Path(sys.argv[1]).stat().st_size
    print(f"{dest}\n  {src/1e6:.1f}MB set -> {dest.stat().st_size/1e6:.2f}MB one-track set")


if __name__ == "__main__":
    main()
