#!/usr/bin/env python3
"""
crate — index Ableton Live layers for fast search, preview and one-click load.

Two sources:
  A. the curated layer library  (04 Samples/04 Instruments)   -> 'library'
  B. drum tracks in past sets   (01 Tracks/<proj>/<proj>.als)  -> 'project'

Sample paths come from each FileRef's RelativePath, not its Path: the absolute
Paths in these sets were written on another machine
(/Users/Jonny/Library/CloudStorage/Dropbox/AN/...) and do not exist here.
"""
from __future__ import annotations

import gzip
import json
import os
import re
import struct
import sys
import time
from pathlib import Path
from urllib.parse import quote
from xml.etree.ElementTree import iterparse

sys.path.insert(0, str(Path(__file__).resolve().parent))
import config  # noqa: E402

_CFG = config.load()
TRACKS_ROOT = _CFG["projects_root"]
LIBRARY_ROOT = _CFG["library_root"]
# Samples are resolved relative to anything the config says is a root, so a
# reference reaching out of its project still finds its file.
AN = TRACKS_ROOT.parent

AUDIO_EXT = (".wav", ".aif", ".aiff", ".flac", ".mp3", ".m4a", ".ogg")
TRACK_TAGS = {"AudioTrack", "MidiTrack", "GroupTrack", "ReturnTrack"}
LOADABLE_EXT = (".als", ".adg", ".adv")

# A track counts as a drum layer if any of these appear in its own name or in
# the name of any group above it.
DRUM_WORDS = re.compile(
    r"\b(drum|drumz|kick|snare|clap|hat|hihat|ohat|clhat|perc|rim|ride|crash|"
    r"cymbal|tom|tabla|shaker|tamb|conga|bongo|break|rumble|sub ?kick|808)\b|"
    r">>> ?(racks|kicks|snares|high perc|low perc)",
    re.I,
)
# Groups in the template whose children are drums regardless of their own name.
DRUM_GROUPS = re.compile(r"^(drums|>>> ?(racks|kicks|snares|high perc|low perc))$", re.I)

# Ported from ul-sample-organizer/classify.mjs so the two tools agree on what
# a thing is called. Matching runs on a string where _ - . become spaces.
CATEGORY_RULES: list[tuple[str, re.Pattern]] = [
    ("kick", re.compile(r"\bkicks?\b|\bkiks?\b|\bbd\b|\bbassdrum", re.I)),
    ("snare", re.compile(r"snares?|\bsnr\b|\bsd\b", re.I)),
    ("clap", re.compile(r"claps?", re.I)),
    ("hat", re.compile(r"\bhi ?hats?\b|\bhats?\b|\bhh\b|open hat|closed hat|\bohh?\b|\bchh?\b", re.I)),
    ("perc", re.compile(r"percs?\b|percussion|shaker|tamb|conga|bongo|\brims?\b|rimshot|cowbell|block", re.I)),
    ("cymbal", re.compile(r"\bride\b|crash|cymbal", re.I)),
    ("tom", re.compile(r"\btoms?\b", re.I)),
    ("808", re.compile(r"808")),
    ("break", re.compile(r"breaks?\b|breakbeat|amen|think break", re.I)),
    ("drums", re.compile(r"\bdrums?\b|drum loop|top loop|\btops?\b|\bfills?\b", re.I)),
    ("bass", re.compile(r"\bbass|\bsub\b|reese", re.I)),
    ("vocal", re.compile(r"vocals?|\bvox\b|acapella|adlib|chant|choir|phrase", re.I)),
    ("pad", re.compile(r"\bpads?\b", re.I)),
    ("lead", re.compile(r"\bleads?\b", re.I)),
    ("pluck", re.compile(r"plucks?", re.I)),
    ("keys", re.compile(r"piano|\bkeys\b|rhodes|organ|\bep\b", re.I)),
    ("guitar", re.compile(r"guitar|\bgtr\b", re.I)),
    ("strings", re.compile(r"strings?\b|violin|cello", re.I)),
    ("brass", re.compile(r"brass|trumpet|\bsax\b|\bhorns?\b", re.I)),
    ("synth", re.compile(r"synth", re.I)),
    ("fx", re.compile(r"\bfx\b|riser|sweep|impact|downlifter|uplifter|whoosh|\bnoise\b|transition|\bsfx\b", re.I)),
    ("texture", re.compile(r"texture|ambien|atmos|drone|\bfield\b|foley", re.I)),
    ("chord", re.compile(r"chords?\b|stabs?\b", re.I)),
]


def guess_tag(*parts: str) -> str | None:
    """First taxonomy hit, most specific rules first. Title wins over samples."""
    for p in parts:
        if not p:
            continue
        s = re.sub(r"[_\-.]", " ", p)
        for tag, rx in CATEGORY_RULES:
            if rx.search(s):
                return tag
    return None


DRUM_TYPE = re.compile(
    r"\b(kick|snare|clap|hihat|hat|ohat|clhat|perc|rim|ride|crash|cymbal|tom|"
    r"tabla|shaker|tambourine|tamb|conga|bongo|break|breakbeat|rumble|clave)\b",
    re.I,
)

DEVICE_TAGS = {
    "DrumGroupDevice": "Drum Rack",
    "InstrumentGroupDevice": "Instrument Rack",
    "AudioEffectGroupDevice": "FX Rack",
    "OriginalSimpler": "Simpler",
    "MultiSampler": "Sampler",
    "Operator": "Operator",
    "UltraAnalog": "Analog",
    "InstrumentImpulse": "Impulse",
    "Wavetable": "Wavetable",
    "PluginDevice": "Plug-in",
    "AuPluginDevice": "Plug-in",
}


# --------------------------------------------------------------------------- #
# sample path resolution
# --------------------------------------------------------------------------- #
def remap_abs(p: str) -> Path | None:
    """Rewrite a foreign absolute path that still points inside Dropbox/AN."""
    m = re.search(r"/Dropbox/AN/(.*)$", p)
    return (AN / m.group(1)) if m else None


def resolve_sample(rel: str | None, absolute: str | None, bases: list[Path]) -> Path | None:
    """First existing candidate: RelativePath against each base, then the remap."""
    if rel:
        rel_clean = rel.lstrip("/")
        for b in bases:
            try:
                cand = (b / rel_clean).resolve()
            except Exception:
                continue
            if cand.exists():
                return cand
    if absolute:
        cand = remap_abs(absolute)
        if cand and cand.exists():
            return cand
        p = Path(absolute)
        if p.exists():
            return p
    return None


# --------------------------------------------------------------------------- #
# .als / .adg parsing
# --------------------------------------------------------------------------- #
def parse_live_file(path: Path) -> dict:
    """Stream a gzipped Live XML document into tracks + device/sample metadata.

    Tracks are a flat list; nesting is expressed by TrackGroupId pointing at a
    GroupTrack's Id (-1 means top level). Devices *are* nested inside their
    track element, so attributing samples to a track by XML containment works.
    """
    tracks: list[dict] = []
    cur: dict | None = None
    file_rel: str | None = None
    file_abs: str | None = None
    loose_devices: list[str] = []
    loose_samples: list[tuple[str | None, str | None]] = []
    # Clips on the arrangement timeline sit under MainSequencer >
    # ArrangerAutomation. Both markers are needed: ArrangerAutomation also
    # wraps every automation lane, and MainSequencer appears per track.
    seq_depth = arr_depth = plug_depth = 0
    plug_named = False

    with gzip.open(path, "rb") as fh:
        for ev, el in iterparse(fh, events=("start", "end")):
            tag = el.tag
            if ev == "start":
                if tag in TRACK_TAGS:
                    cur = {
                        "kind": tag,
                        "id": el.get("Id"),
                        "group_id": None,
                        "name": None,
                        "chain_names": [],
                        "devices": [],
                        "samples": [],
                        "arr_clips": 0,
                        "plugins": [],
                    }
                elif tag == "PluginDesc":
                    plug_depth += 1
                    plug_named = False
                elif tag == "FileRef":
                    file_rel = file_abs = None
                elif tag == "MainSequencer":
                    seq_depth += 1
                elif tag == "ArrangerAutomation":
                    arr_depth += 1
                elif tag in ("MidiClip", "AudioClip") and cur and seq_depth and arr_depth:
                    cur["arr_clips"] += 1
                continue

            if tag == "MainSequencer":
                seq_depth -= 1
            elif tag == "ArrangerAutomation":
                arr_depth -= 1
            elif tag == "PluginDesc":
                plug_depth -= 1
            elif tag == "Name" and plug_depth and not plug_named and cur is not None:
                # A plug-in's real name sits in <PluginDesc><AuPluginInfo><Name>,
                # ahead of the nested preset's own Name — so the first one wins.
                v = el.get("Value")
                if v:
                    plug_named = True
                    if v not in cur["plugins"]:
                        cur["plugins"].append(v)

            # ev == "end"
            if tag == "RelativePath":
                file_rel = el.get("Value")
            elif tag == "Path":
                file_abs = el.get("Value")
            elif tag == "FileRef":
                if (file_rel or file_abs) and str(file_rel or file_abs).lower().endswith(AUDIO_EXT):
                    pair = (file_rel, file_abs)
                    (cur["samples"] if cur else loose_samples).append(pair)
                file_rel = file_abs = None
            elif tag == "TrackGroupId" and cur:
                cur["group_id"] = el.get("Value")
            elif tag == "EffectiveName" and cur:
                v = el.get("Value")
                if v:
                    if cur["name"] is None:
                        cur["name"] = v
                    elif len(cur["chain_names"]) < 64 and v not in cur["chain_names"]:
                        cur["chain_names"].append(v)
            elif tag in DEVICE_TAGS:
                label = DEVICE_TAGS[tag]
                target = cur["devices"] if cur else loose_devices
                if label not in target:
                    target.append(label)
            elif tag in TRACK_TAGS:
                tracks.append(cur)
                cur = None

            if tag not in ("Tracks",):
                el.clear()

    return {"tracks": tracks, "loose_devices": loose_devices, "loose_samples": loose_samples}


def group_path(tr: dict, by_id: dict) -> list[str]:
    """Names of the groups above a track, outermost first."""
    out, gid, guard = [], tr.get("group_id"), 0
    while gid and gid != "-1" and guard < 12:
        parent = by_id.get(gid)
        if not parent:
            break
        out.append(parent.get("name") or "?")
        gid = parent.get("group_id")
        guard += 1
    return list(reversed(out))


NON_DRUM_TOP = re.compile(r"^(bass|sub|mids|vox|fx|references|sidechain)$", re.I)
STRONG_DRUM = re.compile(
    r"\b(kick|snare|clap|hat|hihat|ohat|clhat|perc|rim|ride|crash|cymbal|tom|"
    r"tabla|shaker|tamb|conga|bongo|break|drum|drumz)\b", re.I
)


def is_drum_layer(name: str, groups: list[str]) -> bool:
    if groups and NON_DRUM_TOP.match(groups[0].strip()):
        # A track under BASS/SUB/MIDS is only a drum if it says so outright;
        # a loose word like "808" in a bass name is not enough.
        return bool(STRONG_DRUM.search(name or ""))
    if any(DRUM_GROUPS.match(g.strip()) for g in groups):
        return True
    return bool(DRUM_WORDS.search(name or "") or any(DRUM_WORDS.search(g) for g in groups))


def is_template_placeholder(name: str, devices: list[str], samples: list) -> bool:
    """An untouched slot in the template: still named after its position (bare,
    or with Live's default device suffix), no samples, nothing but an Operator.
    These make up most of a 40-track set and none of them are layers."""
    if samples:
        return False
    m = re.match(r"^(\d+)\s*[-_ ]?\s*(.*)$", (name or "").strip())
    if not m:
        return False
    rest = m.group(2).strip()
    if rest and not re.fullmatch(r"operator|midi|audio", rest, re.I):
        return False
    return not devices or set(devices) <= {"Operator"}


# --------------------------------------------------------------------------- #
# browser URI
# --------------------------------------------------------------------------- #
def uri_for(path: Path) -> str | None:
    """Live browser URI for a file inside the 'AN' Place."""
    for root in (AN, _CFG["user_library"]):
        try:
            rel = path.relative_to(root)
        except ValueError:
            continue
        return "userfolder:%s#%s" % (root, ":".join(quote(p) for p in rel.parts))
    return None


# --------------------------------------------------------------------------- #
# what a layer feeds on
# --------------------------------------------------------------------------- #
def sample_names(paths: list[Path], limit: int = 16) -> list[str]:
    """The names of the samples a layer draws on — names only, not audio.

    There were playable previews here once, built from these files. They were
    misleading: a layer's sound is its whole chain, and the raw sample going in
    can be nothing like what comes out the other end. The names are still worth
    keeping because they are worth searching — "KSHMR" finds every layer built
    on that pack — but nothing here claims to be an audition.
    """
    out: list[str] = []
    for p in paths:
        if p.name not in out:
            out.append(p.name)
        if len(out) >= limit:
            break
    return out


def norm_stem(s: str) -> str:
    s = re.sub(r"\[[^\]]*\]", " ", s)          # drop [2026-10-04 171435]
    s = re.sub(r"^bounce\s+", " ", s, flags=re.I)
    s = re.sub(r"^\d+[- ]", " ", s)            # drop a leading track number
    s = re.sub(r"-\d+$", " ", s)               # drop the -1 bounce suffix
    s = re.sub(r"[^a-z0-9]+", " ", s.lower())
    return " ".join(s.split())


# --------------------------------------------------------------------------- #
# scanners
# --------------------------------------------------------------------------- #
def scan_library() -> list[dict]:
    """The curated AN<n>-Category-Type-Name layer exports."""
    entries = []
    if not LIBRARY_ROOT or not LIBRARY_ROOT.is_dir():
        return entries
    for item in sorted(LIBRARY_ROOT.iterdir()):
        if item.name.startswith("."):
            continue
        if item.is_dir():
            inner = sorted(item.glob("*.als"))
            if not inner:
                continue
            live_file, label, bases = inner[0], item.name, [item, LIBRARY_ROOT, AN]
        elif item.suffix.lower() in LOADABLE_EXT:
            live_file, label, bases = item, item.stem, [LIBRARY_ROOT, AN, item.parent]
        else:
            continue

        try:
            parsed = parse_live_file(live_file)
        except Exception as e:
            print(f"  ! {item.name}: {e}", file=sys.stderr)
            continue

        by_id = {t["id"]: t for t in parsed["tracks"] if t.get("id")}
        devices, samples, chain, plugins = (list(parsed["loose_devices"]),
                                            list(parsed["loose_samples"]), [], [])
        track_names = []
        kind = None
        for t in parsed["tracks"]:
            if t["kind"] == "ReturnTrack":
                continue
            if kind is None and t["kind"] in ("MidiTrack", "AudioTrack"):
                kind = "midi" if t["kind"] == "MidiTrack" else "audio"
            track_names.append(t["name"] or "?")
            devices += [d for d in t["devices"] if d not in devices]
            plugins += [p for p in t["plugins"] if p not in plugins]
            samples += t["samples"]
            chain += t["chain_names"]

        resolved = [r for r in (resolve_sample(rel, ab, bases) for rel, ab in samples) if r]
        # A collected Project folder keeps its audio next to the set even when
        # the set's own FileRefs no longer resolve — use it as a fallback.
        if not resolved and item.is_dir():
            sdir = item / "Samples"
            if sdir.is_dir():
                resolved = sorted(
                    f for f in sdir.rglob("*") if f.suffix.lower() in AUDIO_EXT
                )[:12]

        m = re.match(r"^AN(\d+)[-_](\w+?)[-_](.*)$", label)
        gen = int(m.group(1)) if m else None
        category = m.group(2) if m else None
        rest = m.group(3) if m else label
        tm = DRUM_TYPE.search(label)
        sub = tm.group(0).title() if tm else (rest.split("-")[0] if m and "-" in rest else None)

        samples = sample_names(resolved)
        entries.append({
            "source": "library",
            "id": "lib:" + label,
            "title": label,
            "gen": gen,
            "category": category,
            "kind": kind or ("midi" if devices else "audio"),
            "subtype": sub,
            "tag": guess_tag(label, sub or "", " ".join(samples)),
            "project": None,
            "groups": [],
            "track_names": track_names[:8],
            "devices": devices[:10],
            "chain_names": sorted(set(chain))[:40],
            "file": str(live_file),
            "loadable": live_file.suffix.lower() in LOADABLE_EXT,
            "uri": uri_for(live_file),
            "plugins": plugins[:8],
            "mtime": live_file.stat().st_mtime,
            "samples": samples,
        })
    return entries


def pick_main_als(project_dir: Path) -> Path | None:
    cands = [p for p in project_dir.glob("*.als") if not p.name.startswith(".")]
    if not cands:
        return None
    exact = [p for p in cands if p.stem == project_dir.name]
    if exact:
        return exact[0]
    return max(cands, key=lambda p: p.stat().st_mtime)


def project_number(d: Path) -> int | None:
    m = re.match(r"\s*(\d+)", d.name)
    return int(m.group(1)) if m else None


def scan_projects(min_number: int) -> list[dict]:
    """Drum tracks out of projects numbered `min_number` and up.

    The folders are numbered chronologically, so a floor is a cleaner cut than
    a recency window: it tracks how the sound has moved on rather than which
    files happen to have been touched lately.
    """
    entries = []
    if not TRACKS_ROOT.is_dir():
        return entries
    def wanted(d: Path) -> bool:
        n = project_number(d)
        # 900+ is a holding bucket (999 misc, 999 test), not later work.
        return n is not None and min_number <= n < 900

    projects = sorted(
        (d for d in TRACKS_ROOT.iterdir()
         if d.is_dir() and not d.name.startswith(".") and wanted(d)),
        key=lambda d: (project_number(d) or 0),
        reverse=True,
    )

    for pdir in projects:
        als = pick_main_als(pdir)
        if not als:
            continue
        t0 = time.time()
        try:
            parsed = parse_live_file(als)
        except Exception as e:
            print(f"  ! {pdir.name}: {e}", file=sys.stderr)
            continue
        by_id = {t["id"]: t for t in parsed["tracks"] if t.get("id")}
        bases = [pdir, TRACKS_ROOT, AN]
        kept = 0

        for t in parsed["tracks"]:
            if t["kind"] in ("ReturnTrack", "GroupTrack"):
                continue
            # A layer counts only if it was actually used: a clip on the
            # arrangement timeline. This replaces every heuristic that used to
            # guess at template placeholders — an untouched slot has no clips,
            # and neither do the reference and sidechain utility tracks.
            if not t.get("arr_clips"):
                continue
            # Scoped to MIDI for now. An audio track is a performance, not an
            # instrument: bringing it over means recreating every clip on the
            # timeline, which is a separate job.
            if t["kind"] != "MidiTrack":
                continue
            # Nothing on the track means nothing to bring over.
            if not t["devices"]:
                continue
            name = t["name"] or "?"
            groups = group_path(t, by_id)
            # REFERENCES holds other people's records for comparison, and
            # SIDECHAIN holds routing utilities. Both carry clips; neither is
            # a layer of yours.
            if groups and groups[0].strip().upper() in ("REFERENCES", "SIDECHAIN"):
                continue

            resolved = [r for r in (resolve_sample(rel, ab, bases) for rel, ab in t["samples"]) if r]
            samples = sample_names(resolved)
            sub = groups[-1].replace(">>>", "").strip() if groups else None
            entries.append({
                "source": "project",
                "id": f"proj:{pdir.name}:{t['id']}",
                "title": name,
                "gen": None,
                # The top-level group is the layer's part of the arrangement:
                # DRUMS, MIDS, BASS, VOX, FX.
                "category": groups[0] if groups else None,
                "kind": "midi" if t["kind"] == "MidiTrack" else "audio",
                "arr_clips": t["arr_clips"],
                "subtype": sub,
                "tag": guess_tag(name, sub or "", " ".join(groups),
                                 " ".join(samples)),
                "project": pdir.name,
                "groups": groups,
                "track_names": [name],
                "devices": t["devices"][:10],
                "plugins": t["plugins"][:8],
                "chain_names": sorted(set(t["chain_names"]))[:40],
                "file": str(als),
                "loadable": False,  # a track inside a set, not a standalone item
                "uri": None,
                "mtime": als.stat().st_mtime,
                "samples": samples,
            })
            kept += 1
        print(f"  {pdir.name}: {kept} layers  ({time.time() - t0:.1f}s)", file=sys.stderr)
    return entries


LIB_PREFIX = re.compile(r"^AN\d+[-_]\w+[-_]", re.I)


def canon_name(e: dict) -> str:
    t = e["title"]
    if e["source"] == "library":
        t = LIB_PREFIX.sub("", t)
        t = re.sub(r"\s+Project$", "", t)
    return norm_stem(t)


def collapse_repeats(entries: list[dict]) -> list[dict]:
    """The same layer reused across sets should appear once, not N times.

    Identity is the normalised name plus the set of samples it plays, so two
    tracks called "hat sticky" that reference the same files collapse, while a
    different "hat sticky" built on other samples stays separate.
    """
    buckets: dict[tuple, list[dict]] = {}
    out = [e for e in entries if e["source"] != "project"]
    for e in entries:
        if e["source"] != "project":
            continue
        sig = (canon_name(e), tuple(sorted(e["samples"])))
        buckets.setdefault(sig, []).append(e)
    for grp in buckets.values():
        grp.sort(key=lambda x: x["mtime"], reverse=True)
        head = grp[0]
        head["seen_in"] = sorted({g["project"] for g in grp})
        head["reuse"] = len(head["seen_in"])
        out.append(head)
    return out


def link_twins(entries: list[dict]) -> None:
    """Point a project layer at its curated library version, when one exists.

    A twin is what makes a project layer loadable: the track itself lives
    inside a 40-track set, but its exported twin is a single loadable file.
    """
    lib = [e for e in entries if e["source"] == "library" and e["loadable"]]
    by_name: dict[str, dict] = {}
    by_sample: dict[str, dict] = {}
    for e in lib:
        by_name.setdefault(canon_name(e), e)
        for nm in e["samples"]:
            by_sample.setdefault(nm, e)

    for e in entries:
        if e["source"] != "project":
            continue
        hit = by_name.get(canon_name(e))
        if not hit:
            for nm in e["samples"]:
                if nm in by_sample:
                    hit = by_sample[nm]
                    break
        if hit:
            e["twin"] = {"title": hit["title"], "uri": hit["uri"], "id": hit["id"]}


MIN_PROJECT = _CFG["min_project"]  # 0 means every project


def main() -> None:
    min_number = int(sys.argv[1]) if len(sys.argv) > 1 else MIN_PROJECT
    out = Path(sys.argv[2]) if len(sys.argv) > 2 else config.INDEX_FILE

    print("scanning curated library…", file=sys.stderr)
    lib = scan_library()
    print(f"  {len(lib)} entries", file=sys.stderr)

    print(f"scanning projects {min_number} and up…", file=sys.stderr)
    proj = scan_projects(min_number)
    raw_proj = len(proj)

    entries = collapse_repeats(lib + proj)
    link_twins(entries)
    entries.sort(key=lambda e: (-e["mtime"], e["title"]))

    n_lib = sum(1 for e in entries if e["source"] == "library")
    index = {
        "built": time.time(),
        "projects_root": str(TRACKS_ROOT),
        "min_project": min_number,
        "counts": {
            "library": n_lib,
            "project": len(entries) - n_lib,
            "project_before_collapse": raw_proj,
            "twinned": sum(1 for e in entries if e.get("twin")),
        },
        "entries": entries,
    }
    out.write_text(json.dumps(index, indent=1))
    n_samp = sum(1 for e in index["entries"] if e["samples"])
    print(
        f"\nwrote {out}\n  {len(index['entries'])} layers, "
        f"{n_samp} naming their samples",
        file=sys.stderr,
    )


if __name__ == "__main__":
    main()
