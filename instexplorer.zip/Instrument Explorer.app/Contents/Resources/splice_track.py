#!/usr/bin/env python3
"""
Move a track from one Live set into another, at the file level.

This is the lossless route: the track's XML is carried across whole, so clips,
automation, warp markers, fades, mixer values and everything else nobody
thought to enumerate come with it. Nothing is interpreted.

It only applies to a set Live does not currently have open. Live holds its
document in memory and writes it out wholesale on save, so splicing into the
open set's file is invisible at best and destroys the splice at worst — see
`refuse_if_open()`.

Three fixups are needed to make a foreign track legal in its new home:

  * ids — every Id in the incoming track is shifted into the destination's
    free range by a single uniform offset, which keeps the track's internal
    cross-references intact while guaranteeing no collision;
  * placement — TrackGroupId is pointed at the destination's group, and the
    element is inserted after that group's last member so document order
    matches membership;
  * samples — paths are repointed, since the source set's relative paths are
    relative to *its* folder.
"""
from __future__ import annotations

import gzip
import re
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from extract_track import ExtractError, repoint_samples  # noqa: E402
from make_adg import element, strip_tag  # noqa: E402

TRACK_RE = re.compile(r'<(AudioTrack|MidiTrack|GroupTrack) Id="(\d+)"')
ID_ATTR_RE = re.compile(r'( Id=")(\d+)(")')
POINTEE_RE = re.compile(r'(<Pointee Id=")(\d+)(")')


class SpliceError(RuntimeError):
    pass


# --------------------------------------------------------------------------- #
def read_set(path: Path) -> str:
    if not path.exists():
        raise SpliceError(f"missing set: {path}")
    if path.stat().st_size == 0:
        raise SpliceError(f"{path.name} is 0 bytes — Dropbox may have it online-only")
    try:
        return gzip.decompress(path.read_bytes()).decode("utf-8", "replace")
    except OSError as e:
        raise SpliceError(f"{path.name} is not a readable Live set ({e})")


def track_span(doc: str, track_id: str) -> tuple[int, int, str]:
    for m in TRACK_RE.finditer(doc):
        if m.group(2) == track_id:
            close = f"</{m.group(1)}>"
            end = doc.find(close, m.end())
            if end == -1:
                raise SpliceError(f"unterminated track {track_id}")
            return m.start(), end + len(close), m.group(1)
    raise SpliceError(f"track {track_id} not found")


def groups(doc: str) -> dict[str, str]:
    """{group name: its Id} for every GroupTrack in the set."""
    out = {}
    for m in TRACK_RE.finditer(doc):
        if m.group(1) != "GroupTrack":
            continue
        end = doc.find("</GroupTrack>", m.end())
        body = doc[m.start():end]
        nm = re.search(r'<EffectiveName Value="([^"]*)"', body)
        if nm:
            out.setdefault(nm.group(1), m.group(2))
    return out


def last_member_end(doc: str, group_id: str) -> int | None:
    """End offset of the last track belonging to `group_id`, in document order."""
    end = None
    for m in TRACK_RE.finditer(doc):
        close = f"</{m.group(1)}>"
        stop = doc.find(close, m.end())
        body = doc[m.start():stop]
        g = re.search(r'<TrackGroupId Value="(-?\d+)"', body)
        if g and g.group(1) == group_id:
            end = stop + len(close)
    return end


def next_pointee(doc: str) -> int:
    m = re.search(r'<NextPointeeId Value="(\d+)"', doc)
    if not m:
        raise SpliceError("destination has no NextPointeeId")
    return int(m.group(1))


def shift_ids(fragment: str, offset: int) -> tuple[str, int]:
    """Shift every Id in the fragment by `offset`; return (xml, highest id used).

    A uniform shift is what makes this safe: references inside the track point
    at other ids inside the same track, so moving them all by the same amount
    preserves every relationship while clearing the destination's range.
    """
    top = 0

    def bump(m: re.Match) -> str:
        nonlocal top
        v = int(m.group(2)) + offset
        top = max(top, v)
        return f"{m.group(1)}{v}{m.group(3)}"

    out = ID_ATTR_RE.sub(bump, fragment)
    out = POINTEE_RE.sub(bump, out)
    return out, top


# --------------------------------------------------------------------------- #
def refuse_if_open(target: Path, open_set_path: str | None) -> None:
    """Never write a set Live currently holds.

    Live writes its whole in-memory document on save, so a splice into the open
    set is invisible until reload and is erased by the next Cmd+S.
    """
    if open_set_path and Path(open_set_path).resolve() == target.resolve():
        raise SpliceError(
            f"{target.name} is open in Live right now. Live would overwrite this "
            "splice on its next save. Close the set first, or use the API path."
        )


def splice(target: Path, source: Path, track_id: str,
           group: str | None = None, backup: bool = True,
           open_set_path: str | None = None) -> dict:
    refuse_if_open(target, open_set_path)

    dst = read_set(target)
    src = read_set(source)
    s, e, kind = track_span(src, track_id)
    fragment = src[s:e]

    # ids into the destination's free range
    base = next_pointee(dst)
    fragment, top = shift_ids(fragment, base)

    # placement
    gid = "-1"
    insert_at = None
    if group:
        gmap = groups(dst)
        if group in gmap:
            gid = gmap[group]
            insert_at = last_member_end(dst, gid)
            if insert_at is None:  # empty group: sit right after its header
                gs, ge, _ = track_span(dst, gid)
                insert_at = ge
    fragment = re.sub(r'<TrackGroupId Value="-?\d+" />',
                      f'<TrackGroupId Value="{gid}" />', fragment, count=1)

    if insert_at is None:
        r = element(dst, "Tracks")
        if not r:
            raise SpliceError("destination has no <Tracks>")
        insert_at = dst.rindex("</Tracks>", r[0], r[1])

    # samples, relative to the destination's folder
    fragment = repoint_samples(fragment.encode("utf-8"),
                               source.parent, target.parent).decode("utf-8", "replace")

    merged = dst[:insert_at] + "\n" + fragment + "\n" + dst[insert_at:]
    merged = re.sub(r'<NextPointeeId Value="\d+"',
                    f'<NextPointeeId Value="{top + 1}"', merged, count=1)

    if backup:
        bak = target.with_suffix(target.suffix + ".bak")
        if not bak.exists():
            shutil.copy2(target, bak)
    target.write_bytes(gzip.compress(merged.encode("utf-8"), 1))

    return {
        "target": str(target),
        "track_kind": kind,
        "group": group if gid != "-1" else None,
        "id_offset": base,
        "next_pointee": top + 1,
        "bytes": target.stat().st_size,
    }


def main() -> None:
    if len(sys.argv) < 4:
        print("usage: splice_track.py <target.als> <source.als> <track_id> [group]",
              file=sys.stderr)
        raise SystemExit(2)
    r = splice(Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3],
               sys.argv[4] if len(sys.argv) > 4 else None)
    print(r)


if __name__ == "__main__":
    main()
